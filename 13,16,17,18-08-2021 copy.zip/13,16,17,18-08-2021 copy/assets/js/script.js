/*Header js start*/
$('document').ready(function() {
    $('#toggle').click(function() {
        $(this).toggleClass('active');
        $('#overlay').toggleClass('open');
    });
});

/*Header js end*/

/*Fixed header on scroll js start*/


$(window).scroll(function() {
    if ($(window).scrollTop() >= 200) {
        $('header').addClass('fixed');
    } else {
        $('header').removeClass('fixed');
    }
});

/*Fixed header on scroll js end*/


/*Banner slider js start*/
var $imagesSlider = $(".gallery-slider .gallery-slider__images>div"),
    $thumbnailsSlider = $(".gallery-slider__thumbnails>div");

// images options
$imagesSlider.slick({
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    cssEase: 'linear',
    fade: true,
    draggable: false,
    asNavFor: ".gallery-slider__thumbnails>div",
    prevArrow: '.gallery-slider__images .prev-arrow',
    nextArrow: '.gallery-slider__images .next-arrow'
});

// thumbnails options
$thumbnailsSlider.slick({
    speed: 300,
    slidesToShow: 1,
    slidesToScroll: 1,
    cssEase: 'linear',
    centerMode: true,
    variableWidth: false,
    draggable: false,
    focusOnSelect: true,
    asNavFor: ".gallery-slider .gallery-slider__images>div",
    prevArrow: '.gallery-slider__thumbnails .prev-arrow',
    nextArrow: '.gallery-slider__thumbnails .next-arrow',
    responsive: [{
        breakpoint: 720,
        settings: {
            slidesToShow: 1,
            slidesToScroll: 1
        }
    }, ]
});

/*Banner slider js end*/

/*Travel sectino slider js start*/
$('.responsive-slider').slick({
    dots: false,
    infinite: true,
    speed: 300,
    arrows: false,
    slidesToShow: 4,
    slidesToScroll: 1,
    responsive: [{
            breakpoint: 992,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                infinite: true,
                dots: false,
                arrows: false
            }
        },
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                infinite: true,
                dots: false,
                arrows: false
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }
    ]
});
/*Travel section slider js end*/

/*Featured stories section js start */

$(document).ready(function() {
    var galleryThumbs = new Swiper(".gallery-thumbs", {
        direction: "horizontal",
        spaceBetween: 10,
        slidesPerView: 3,
        freeMode: false,
        watchSlidesVisibility: true,
        watchSlidesProgress: true,
        breakpoints: {
            480: {
                direction: "vertical",
                slidesPerView: 3,
            }
        }
    });
    var galleryTop = new Swiper(".gallery-top", {
        direction: "horizontal",
        spaceBetween: 10,
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },
        thumbs: {
            swiper: galleryThumbs
        }
    });
});

/*Featured stories section js end*/


/*Featured Videos section js start*/
var $st = $('.pagination');
var $slickEl = $('.center');

$slickEl.on('init reInit afterChange', function(event, slick, currentSlide, nextSlide) {
    var i = (currentSlide ? currentSlide : 0) + 1;
    $st.text(i + ' of ' + slick.slideCount);
});

$slickEl.slick({
    centerMode: true,
    centerPadding: '200px',
    slidesToShow: 1,
    focusOnSelect: true,
    dots: false,
    infinite: true,
    autoplay: true,
    arrows: false,
    variableWidth: true,
    responsive: [{
            breakpoint: 768,
            settings: {
                arrows: false,
                centerMode: true,
                centerPadding: '40px',
                slidesToShow: 1
            }
        },
        {
            breakpoint: 480,
            settings: {
                arrows: false,
                centerMode: true,
                centerPadding: '40px',
                slidesToShow: 1
            }
        }
    ]
});

/*Featured Videos section js end*/

/*Featured play video section js start*/


$('#play-video2').on('click', function(e) {
    e.preventDefault();
    $('#video-overlay2').addClass('open');
    $("#video-overlay2").append('<iframe width="560" height="315" src="https://www.youtube.com/embed/ngElkyQ6Rhs" frameborder="0" allowfullscreen></iframe>');
});

$('.video-overlay, .video-overlay-close').on('click', function(e) {
    e.preventDefault();
    close_video();
});

$(document).keyup(function(e) {
    if (e.keyCode === 27) {
        close_video();
    }
});

function close_video() {
    $('.video-overlay.open').removeClass('open').find('iframe').remove();
};

/*Featured play video section js end*/


/*Animation js start*/
$(window).scroll(function() {
    AOS.init({
        duration: 2000,
    })
});
/*Animation js end*/

/*Banner Video js start*/
$(".box-video").click(function() {
    $('iframe', this)[0].src += "&amp;autoplay=1";
    $(this).addClass('open');
});
/*Banner Video js end*/

/*Blog Video js start*/
$('#play-video').on('click', function(e) {
    e.preventDefault();
    $('#video-overlay').addClass('open');
    $("#video-overlay").append('<iframe width="560" height="315" src="https://www.youtube.com/embed/ngElkyQ6Rhs" frameborder="0" allowfullscreen></iframe>');
});

$('.video-overlay, .video-overlay-close').on('click', function(e) {
    e.preventDefault();
    close_video();
});

$(document).keyup(function(e) {
    if (e.keyCode === 27) {
        close_video();
    }
});

function close_video() {
    $('.video-overlay.open').removeClass('open').find('iframe').remove();
};

$('#play-video1').on('click', function(e) {
    e.preventDefault();
    $('#video-overlay1').addClass('open');
    $("#video-overlay1").append('<iframe width="560" height="315" src="https://www.youtube.com/embed/ngElkyQ6Rhs" frameborder="0" allowfullscreen></iframe>');
});

$('.video-overlay, .video-overlay-close').on('click', function(e) {
    e.preventDefault();
    close_video();
});

$(document).keyup(function(e) {
    if (e.keyCode === 27) {
        close_video();
    }
});

function close_video() {
    $('.video-overlay.open').removeClass('open').find('iframe').remove();
};


/*Blog video js end*/